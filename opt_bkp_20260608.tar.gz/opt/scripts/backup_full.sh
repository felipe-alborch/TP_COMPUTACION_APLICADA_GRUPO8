#!/bin/bash

# Variables
FECHA=$(date +%Y%m%d)
ORIGEN=$1
DESTINO=$2

# Funcion de ayuda
ayuda () {
    echo " Como se usa: ./backup_full.sh <ORIGEN> <DESTINO>"
    echo ""
    echo " ORIGEN   : directorio que queremos hacer el backup         (ej: /var/log)"
    echo " DESTINO  : directorio donde se guarda       (ej: /backup_dir)"
    echo ""
    echo " El backup se genera como: {nombre}_bkp_AAAAMMDD.tar.gz"
    echo " Ejemplo: /var/log  ->  log_bkp_20240302.tar.gz"
    echo ""
    echo " Opciones:"
    echo "   -help    Muestra esta ayuda"
    echo ""
}

# Codigo que determina si se tiene que mostrar la ayuda
if [[ "$1" == "-help" || "$1" == "-h" || "$1" == "--help" ]]; then
    ayuda
    exit 0
fi

# Validacion de que la cantidad de argumentos sea la correcta
if [[ $# -ne 2 ]]; then
    echo "ERROR: cantidad de argumentos incorrecta. Se esperaban 2."
    ayuda
    exit 1
fi

# Validacion de que lo que se quiere backupear exista
if [[ ! -d "$ORIGEN" ]]; then
    echo "ERROR: el directorio de origen '$ORIGEN' no existe."
    exit 1
fi

#  Validacion de la direccion de destino exista realmente o que el destino sea un sistema de archivos montado
if [[ ! -d "$DESTINO" ]]; then
    echo "ERROR: el directorio de destino '$DESTINO' no existe."
    exit 1
fi

if ! mountpoint -q "$DESTINO"; then
    echo "ERROR: el destino '$DESTINO' no es un sistema de archivos montado."
    exit 1
fi

# Generacion del nombre del archivo
NOMBRE=$(basename "$ORIGEN")             
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"  

# Creacion del backup
echo "Generando backup de '$ORIGEN' en '$DESTINO/$ARCHIVO' ..."
tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN" 2>/dev/null

# Verificacion del resultado
if [[ $? -eq 0 ]]; then
    echo "OK: backup creado -> $DESTINO/$ARCHIVO"
    exit 0
else
    echo "ERROR: ocurrio un problema al generar el backup."
    exit 1
fi
