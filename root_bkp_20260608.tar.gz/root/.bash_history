history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl set-hostname TPServer
hostname
nano /etc/apt/sources.list
vim /etc/apt/sources.list
apt update
apt full-upgrade
shutdown -r
shutdown -n
shutdown now
apt get openssh-server
apt install openssh-server
nano /etc/ssh/sshd_config
apt install nano
nano /etc/ssh/sshd_config
ls
shutdown now
cd /etc/ssh/
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
ls /root/.ssh/
ip a
ip route
nano /etc/network/interfaces
/etc/init.d/networking restart
ifup enp0s3 
shutdown -r now
ping 8.
ping 8.8.8.8
nano /etc/network/interfaces
/etc/init.d/networking restart
ifup enp0s3 
ping 8.8.8.8
nano /etc/network/interfaces
/etc/init.d/networking restart
ifup enp0s3 
ping 8.8.8.8
nano /etc/network/interfaces
ip -a
ip a
shutdown -r now
ping 8.8.8.8
nano /etc/network/interfaces
/etc/init.d/networking restart
shutdown -r now
ping 8.8.8.8
nano /etc/network/interfaces
/etc/init.d/networking restart
ifup enp0s3 
ping 8.8.8.8
ip route
ip a
nano /etc/network/interfaces
/etc/init.d/networking restart
ifup enp0s3 
ping 8.8.8.8
shutdown -r now
ping 8.8.8.8
ip a
ip route
nano /etc/network/interfaces
clear
ping google.ccom
ping google.com
ping -c4 
ping -c4 8.8.8.8
apt update
ping -c4 192.168.1.1
ping -c4 192.168.1.1
shutdown now
ping -c4 192.168.1.1
ip neigh show
nano /etc/network/interfaces
/etc/init.d/networking restart
ifup enp0s3 
shutdown -r now
ping 8.8.8.8
ping -c4 192.168.1.1
ip neigh show
nano /etc/network/interfaces
/etc/init.d/networking restart
ifup enp0s3 
ping 8.8.8.8
nano /etc/network/interfaces
clear
ping 8.8.8.8
nano /etc/ssh/sshd_config
nano /etc/ssh/sshd_config
shutdown -r now
nano /etc/ssh/sshd_config
clear
systemctl status ssh
systemctl status ssh
nano /etc/ssh/sshd_config
clear
nano /root/.ssh/authorized_keys
clear
ls
nano /etc/ssh/sshd_config
systemctl restart ssh
systemctl status ssh
nano /etc/ssh/sshd_config
systemctl restart ssh
shutdown -r now
systemctl status ssh
nano /etc/ssh/sshd_config
clear
shutdown -r now
nano /etc/ssh/sshd_config
shutdown -r now
nano /etc/ssh/sshd_config
shutdown -r now
ls
mkdir /root/.ssh/authorized_keys
cp id_rsa.pub /root/.ssh/authorized_keys/
chmod 600 /root/.ssh/authorized_keys/
nano /etc/ssh/sshd_config
systemctl restart ssh
nano /etc/ssh/sshd_config
systemctl restart ssh
nano /etc/ssh/sshd_config
systemctl restart ssh
shutdown -r now
ipconfig
ipconf
apt install apache2 php libapache2-mod-php -y
systemctl status apache2
cp index.php /var/www/html/
cp logo.png /var/www/html/
chown -R www-data:www-data /var/www/html/
chmod -R 755 /var/www/html/
systemctl restart apache2
apt install mariadb-server
apt install mariadb-server -y
systemctl status mariadb
mysql -u root < /root/db.sql 
mysql -r root
mysql -u root
apt install php-mysql -y
systemctl restart apache2
ls
chmod 700 /root/.ssh/
cd /root/.ssh/
ls -a
ls -l
rm -rf authorized_keys/
cd 
ls
cat /root/id_rsa.pub >> /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys 
systemctl restart ssh
shutdown  now
lsblk
fdisk /dev/sdc
lsblk
mkfs.ext4 /dev/sdc1 && mkfs.ext4 /dev/sdc2
mkdir /www_dir
mount /dev/sdc1 /www_dir
df -h
mkdir /backup_dir
mount /dev/sdc2 /backup_dir/
df -h
cp index.php /www_dir/
chown -R www-data:www-data /www_dir
chmod -R 755 /www_dir/
nano /etc/apache2/sites-available/000-default.conf 
ls /etc/apache2/
nano /etc/apache2/apache2.conf 
systemctl restart apache2.service 
nano /etc/apache2/apache2.conf 
shutdown -r now
nano /etc/apache2/apache2.conf 
systemctl restart apache2.service 
systemctl restart apache-htcacheclean.service 
nano /etc/fstab 
blkid /dev/sdc1 
blkid /dev/sdc2
nano /etc/fstab 
mount -a
blkid /dev/sdc2
nano /etc/fstab 
mount -a
blkid /dev/sdc2
nano /etc/fstab 
mount -a
nano /etc/fstab 
mount -a
nano /etc/fstab 
mount -a
df -h
shutdown -r now
nano backup_full.sh
clear
nano /opt/scripts/backup_full.sh
clear
mkdir /opt/scripts
nano /opt/scripts/backup_full.sh
clear
cp /root/backup.sh /opt/scripts/backup_full.sh
nano /opt/scripts/backup_full.sh
nano /opt/scripts/backup_full.sh
nano /opt/scripts/backup_full.sh
chmod 755 /opt/scripts/backup_full.sh 
/opt/scripts/backup_full.sh -h
/opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh --help
ls -l /opt/scripts/backup_full.sh 
sed -i 's/\r$//' /opt/scripts/backup_full.sh 
/opt/scripts/backup_full.sh --help
/opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh -h
clear
crontab -e
crontab -e
cat /var/spool/cron/
ls /var/spool/cron/
crontab -e
crontab -l
cat /var/spool/cron/crontabs/root 
crontab -l
cat /var/spool/cron/crontabs/root 
crontab -e
/www_dir/
ls
ls -la
find /www_dir
cat /var/spool/cron/crontabs/root 
clear
cat /var/spool/cron/crontabs/root 
nano /var/spool/cron/crontabs/root 
nano /etc/crontab 
shutdown now
